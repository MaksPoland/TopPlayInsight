#!/bin/bash
cd html_version && python3 -m http.server 8080 --bind 0.0.0.0
